# PUNCH Animation Tools

Small, reproducible tools for building PUNCH/IPS plot animations from existing PNG frame sequences.

This repository builds MP4 movies for products such as:

- density ecliptic cuts
- density meridional cuts
- density synoptic maps
- velocity ecliptic cuts
- velocity meridional cuts
- velocity synoptic maps
- velocity fisheye plots
- velocity Hammer–Aitoff plots
- brightness fisheye 50° and 110° products
- brightness Hammer–Aitoff plots
- optional IPS fisheye products

The scripts do **not** regenerate the scientific PNG plots from `nv3h` files. They take already-generated PNG frames and assemble them into synchronized MP4 files.

---

## Requirements

```bash
bash
ffmpeg
ffprobe
find
sort
sed
awk
comm
```

Check that FFmpeg is available:

```bash
ffmpeg -version
ffprobe -version
```

---

## Expected frame names

The default movie script recognizes these patterns:

```text
PUNCH-IPS_N_Ecliptic-cut_p_*.png
PUNCH-IPS_N_Meridional-cut_p_*.png
PUNCH-IPS_N_Synoptic_map_*.png

PUNCH-IPS_V_Ecliptic-cut_p_*.png
PUNCH-IPS_V_Meridional-cut_p_*.png
PUNCH-IPS_V_Synoptic_map_*.png
PUNCH-IPS_V_Fisheye_*.png
PUNCH-IPS_V_H-A_*.png

PUNCH-IPS_B_H-A_*.png
PUNCH-IPS_B_Fisheye_*_b.png
PUNCH-IPS_B_Fisheye_*_b_small.png
PUNCH-IPS_IPS_Fisheye_*.png
```

Brightness fisheye products are separated by filename suffix:

```text
*_b.png        -> one fisheye field of view
*_b_small.png  -> the other fisheye field of view
```

The repository names these output movies:

```text
B_Fisheye_110.mp4
B_Fisheye_50.mp4
```

Confirm the 50°/110° mapping visually for each new dataset before publishing, because the scientific plotting pipeline controls the actual field of view.

---

# Quick start

Assume the PNG frames are stored in:

```text
/home/soft/vtattala/data/punch_Nov_25_nv3h_images
```

## 1. Audit the frame sequences

```bash
cd /home/soft/vtattala/data/punch_Nov_25_nv3h_images

/path/to/punch_animation_tools/scripts/audit_frames.sh .
```

The audit prints the frame count and the first and last filename for every recognized sequence.

## 2. Move known placeholder frames out of the source directory

Some datasets contain placeholder frames with this timestamp:

```text
20000101-0000UT
```

Move them safely out of the working directory:

```bash
/path/to/punch_animation_tools/scripts/clean_bad_frames.sh .
```

The files are moved into:

```text
excluded_bad_frames/
```

They are not deleted.

Re-run the audit:

```bash
/path/to/punch_animation_tools/scripts/audit_frames.sh .
```

All synchronized products should have the same frame count.

## 3. Build all movies at 4 fps

```bash
/path/to/punch_animation_tools/scripts/make_plot_movies.sh \
  --input . \
  --output movies_4fps \
  --fps 4
```

## 4. Verify durations and frame counts

```bash
/path/to/punch_animation_tools/scripts/verify_movies.sh movies_4fps
```

At 4 fps:

```text
duration = frame count / 4
```

For example:

```text
656 frames / 4 fps = 164 seconds
```

---

# Find a missing timestamp

If one animation is exactly 0.25 seconds shorter at 4 fps, it is missing one frame.

Compare two products:

```bash
/path/to/punch_animation_tools/scripts/compare_timestamps.sh \
  'PUNCH-IPS_N_Ecliptic-cut_p_*.png' \
  'PUNCH-IPS_N_Synoptic_map_*.png'
```

The script reports timestamps present in one sequence but absent from the other.

---

# Recommended complete workflow

```bash
cd /path/to/png_frames

/path/to/punch_animation_tools/scripts/audit_frames.sh .

/path/to/punch_animation_tools/scripts/clean_bad_frames.sh .

/path/to/punch_animation_tools/scripts/audit_frames.sh .

/path/to/punch_animation_tools/scripts/make_plot_movies.sh \
  --input . \
  --output movies_4fps \
  --fps 4

/path/to/punch_animation_tools/scripts/verify_movies.sh movies_4fps
```

---

## Safety behavior

- Source PNGs are never deleted by the movie-building script.
- Placeholder frames are moved, not deleted.
- Missing frame groups are skipped with a clear message.
- Existing MP4 output files are overwritten by FFmpeg only when the movie builder is run.
- Temporary frame-list files are removed automatically.

---

## Repository layout

```text
punch_animation_tools/
├── README.md
├── LICENSE
├── .gitignore
├── scripts/
│   ├── audit_frames.sh
│   ├── clean_bad_frames.sh
│   ├── compare_timestamps.sh
│   ├── make_plot_movies.sh
│   └── verify_movies.sh
└── examples/
    └── example_commands.sh
```
