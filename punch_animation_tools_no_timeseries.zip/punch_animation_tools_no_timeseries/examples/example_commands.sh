#!/usr/bin/env bash

# Example workflow for building PUNCH/IPS plot-sequence animations.

FRAME_DIR="/home/soft/vtattala/data/punch_Nov_25_nv3h_images"
REPO_DIR="/path/to/punch_animation_tools"

cd "$FRAME_DIR"

# 1. Inspect counts and first/last frame names.
"$REPO_DIR/scripts/audit_frames.sh" .

# 2. Safely move known placeholder frames such as 20000101-0000UT.
"$REPO_DIR/scripts/clean_bad_frames.sh" .

# 3. Confirm the remaining sequences are synchronized.
"$REPO_DIR/scripts/audit_frames.sh" .

# 4. Build all recognized MP4 movies at 4 fps.
"$REPO_DIR/scripts/make_plot_movies.sh" \
    --input . \
    --output movies_4fps \
    --fps 4

# 5. Verify output duration, frame count, and average frame rate.
"$REPO_DIR/scripts/verify_movies.sh" movies_4fps

# Optional: compare timestamps when one sequence is shorter.
"$REPO_DIR/scripts/compare_timestamps.sh" \
    'PUNCH-IPS_N_Ecliptic-cut_p_*.png' \
    'PUNCH-IPS_N_Synoptic_map_*.png' \
    .
